const express = require('express');
const multer = require('multer');
const sharp = require('sharp');
const AdmZip = require('adm-zip');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const { PDFDocument } = require('pdf-lib');
const mammoth = require('mammoth');
const ExcelJS = require('exceljs');

const app = express();
const upload = multer({ dest: 'uploads/' });
app.use(cors());
app.use(express.json());

// Image resize
app.post('/edit/image', upload.single('file'), async (req, res) => {
  const filePath = req.file.path;
  const outputPath = `uploads/resized-${Date.now()}.png`;
  await sharp(filePath).resize(300, 300).toFile(outputPath);
  res.download(outputPath, () => {
    fs.unlinkSync(filePath);
    fs.unlinkSync(outputPath);
  });
});

// ZIP extract
app.post('/extract/zip', upload.single('file'), (req, res) => {
  const zip = new AdmZip(req.file.path);
  const extractPath = `uploads/zip-${Date.now()}`;
  zip.extractAllTo(extractPath, true);
  res.json({ files: fs.readdirSync(extractPath) });
});

// PDF merge (basic example)
app.post('/edit/pdf', upload.array('files', 2), async (req, res) => {
  const pdfDoc = await PDFDocument.create();
  for (const file of req.files) {
    const existingPdfBytes = fs.readFileSync(file.path);
    const existingPdf = await PDFDocument.load(existingPdfBytes);
    const copiedPages = await pdfDoc.copyPages(existingPdf, existingPdf.getPageIndices());
    copiedPages.forEach((page) => pdfDoc.addPage(page));
    fs.unlinkSync(file.path);
  }
  const pdfBytes = await pdfDoc.save();
  const outPath = `uploads/merged-${Date.now()}.pdf`;
  fs.writeFileSync(outPath, pdfBytes);
  res.download(outPath, () => fs.unlinkSync(outPath));
});

// Word to text
app.post('/convert/word', upload.single('file'), async (req, res) => {
  const buffer = fs.readFileSync(req.file.path);
  const result = await mammoth.extractRawText({ buffer });
  fs.unlinkSync(req.file.path);
  res.send(result.value);
});

// Excel to JSON
app.post('/convert/excel', upload.single('file'), async (req, res) => {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile(req.file.path);
  const sheet = workbook.worksheets[0];
  const rows = [];
  sheet.eachRow((row) => {
    rows.push(row.values);
  });
  fs.unlinkSync(req.file.path);
  res.json(rows);
});

app.listen(3001, () => {
  console.log('Server started on port 3001');
});


// PDF to Word (placeholder: converts PDF text to .docx)
app.post('/convert/pdf-to-word', upload.single('file'), async (req, res) => {
  const filePath = req.file.path;
  const text = fs.readFileSync(filePath, 'utf8');
  const docx = `PDF Converted to Word:\n${text}`;
  const outPath = `uploads/pdf-to-word-${Date.now()}.docx`;
  fs.writeFileSync(outPath, docx);
  res.download(outPath, () => fs.unlinkSync(outPath));
});

// Word to PDF (placeholder)
app.post('/convert/word-to-pdf', upload.single('file'), async (req, res) => {
  const result = await mammoth.extractRawText({ path: req.file.path });
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage();
  page.drawText(result.value.slice(0, 1000)); // Add first 1000 chars
  const pdfBytes = await pdfDoc.save();
  const outPath = `uploads/word-to-pdf-${Date.now()}.pdf`;
  fs.writeFileSync(outPath, pdfBytes);
  res.download(outPath, () => fs.unlinkSync(outPath));
});

// PDF to Excel (mock)
app.post('/convert/pdf-to-excel', upload.single('file'), async (req, res) => {
  const buffer = fs.readFileSync(req.file.path, 'utf8');
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('PDF Data');
  sheet.addRow(['Mock PDF to Excel Conversion']);
  sheet.addRow([buffer.substring(0, 50)]);
  const outPath = `uploads/pdf-to-excel-${Date.now()}.xlsx`;
  await workbook.xlsx.writeFile(outPath);
  res.download(outPath, () => fs.unlinkSync(outPath));
});

// Excel to PDF (mock)
app.post('/convert/excel-to-pdf', upload.single('file'), async (req, res) => {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile(req.file.path);
  const firstSheet = workbook.worksheets[0];
  let content = '';
  firstSheet.eachRow((row) => {
    content += row.values.join(', ') + '\n';
  });
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage();
  page.drawText(content.slice(0, 1000));
  const pdfBytes = await pdfDoc.save();
  const outPath = `uploads/excel-to-pdf-${Date.now()}.pdf`;
  fs.writeFileSync(outPath, pdfBytes);
  res.download(outPath, () => fs.unlinkSync(outPath));
});
