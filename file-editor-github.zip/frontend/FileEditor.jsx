import { useState } from 'react';

export default function FileEditor() {
  const [file, setFile] = useState(null);
  const [endpoint, setEndpoint] = useState('/edit/image');

  const handleUpload = async () => {
    const formData = new FormData();
    formData.append('file', file);
    const res = await fetch(`http://localhost:3001${endpoint}`, {
      method: 'POST',
      body: formData,
    });

    if (endpoint.includes('/convert') || endpoint === '/convert/word') {
      const text = await res.text();
      alert(text);
    } else {
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      window.open(url);
    }
  };

  return (
    <div className="p-4">
      <select onChange={e => setEndpoint(e.target.value)} className="border p-2 mb-2">
        <option value="/edit/image">Edit Image</option>
        <option value="/extract/zip">Extract ZIP</option>
        <option value="/edit/pdf">Merge PDFs</option>
        <option value="/convert/word">Word to Text</option>
        <option value="/convert/excel">Excel to JSON</option>
              <option value="/convert/pdf-to-word">PDF to Word</option>
        <option value="/convert/word-to-pdf">Word to PDF</option>
        <option value="/convert/pdf-to-excel">PDF to Excel</option>
        <option value="/convert/excel-to-pdf">Excel to PDF</option>
</select>
      <input type="file" onChange={e => setFile(e.target.files[0])} />
      <button onClick={handleUpload} className="bg-blue-500 text-white p-2 rounded mt-2">
        Upload & Process
      </button>
    </div>
  );
}
